package shape;

public interface MySort<T> {
	public T[] bubbleSort(T[] nums);//bubble sort
	public T[] selectSort(T[] nums);//Straight Select Sort
	
}
